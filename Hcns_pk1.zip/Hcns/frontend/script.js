async function sendMessage(){

let input=document.getElementById("userInput")

let text=input.value

if(text==="") return

let chat=document.getElementById("chat-box")

chat.innerHTML+=`<div class="user">${text}</div>`

input.value=""

let response=await fetch(
"http://127.0.0.1:8000/diagnose",
{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
symptoms:text.split(" ")
})
})

let data=await response.json()

displayResult(data)

}

function displayResult(data){

let chat=document.getElementById("chat-box")

let html=""

let labels=[]
let values=[]

data.results.forEach(d=>{

labels.push(d.disease)

values.push(d.confidence)

html+=`
<b>Disease:</b> ${d.disease}<br>
<b>Confidence:</b> ${d.confidence}%<br>
<b>Doctor:</b> ${d.doctor}<br>
<b>Risk:</b> ${d.risk}<br><br>
`

})

data.followup_questions.forEach(q=>{
html+=`<i>${q}</i><br>`
})

chat.innerHTML+=`
<div class="bot">
${html}
<canvas id="chart"></canvas>
</div>
`

createChart(labels,values)

}

function createChart(labels,data){

new Chart(
document.getElementById("chart"),
{
type:"bar",
data:{
labels:labels,
datasets:[{
label:"Probability %",
data:data
}]
}
})
}