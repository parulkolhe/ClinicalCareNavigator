from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

from backend.engine.reasoning_engine import diagnose

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Symptoms(BaseModel):
    symptoms: list[str]


@app.post("/diagnose")
def diagnosis(data: Symptoms):

    result = diagnose(data.symptoms)

    return result